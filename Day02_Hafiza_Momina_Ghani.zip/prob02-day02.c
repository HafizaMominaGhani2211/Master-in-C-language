#include<stdio.h>
int main()
{
	int sum, first, second, third, fourth, fifth;
	float avg;
	printf("Enter five numbers:");
	scanf("%d %d %d %d %d",&first,&second,&third,&fourth,&fifth);
	sum=first+second+third+fourth+fifth;
	printf("Sum: %d",sum);
	avg=sum/5;
	printf("\nAverage: %.2f",avg);
	return 0;
}
