#include<stdio.h>
int main()
{
	int first, second;
	printf("First number:");
	scanf("%d",&first);
	printf("Second number:");
	scanf("%d",&second);
	if(first==second)
	printf("1");
	else
	printf("0");
	return 0;
}
