#include<stdio.h>
int main()
{
	int num1, num2, And, Or, Xor, R_shift, L_shift;
	printf("Enter two numbers:");
	scanf("%d %d",&num1, &num2);
	And=num1&&num2;
	printf("%d & %d = %d\n",num1,num2,And);
	Or=num1|num2;
	printf("%d | %d = %d\n",num1,num2,Or);
	Xor=num1^num2;
	printf("%d ^ %d = %d\n",num1,num2,Xor);
	R_shift=num1>>2;
	printf("%d >> 2 = %d\n",num1,R_shift);
	L_shift=num2<<2;
	printf("%d << 2 = %d\n",num2,L_shift);
	return 0;
}
