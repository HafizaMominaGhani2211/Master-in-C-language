#include<stdio.h>
int main()
{
	int age;
	printf("Age:");
	scanf("%d",&age);
	(age<=18)?printf("Sorry, you are not eligible for vote"):printf("Bravo! you are eligible for vote");
	return 0;
}
