#include<stdio.h>
int main()
{
	int num, result=0, orignal, remainder;
	printf("Enter Number:");
	scanf("%d",&num);
	orignal=num;
	while(orignal!=0)
	{
	remainder=orignal%10;
	result+= remainder*remainder*remainder;
	orignal/=10;
    }
	if(result==num)
	printf("Yes, Armstrong Number.");
	else
	printf("Not Armstrong Number.");
	return 0;
}
