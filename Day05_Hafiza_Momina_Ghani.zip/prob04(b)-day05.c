#include<stdio.h>
int main()
{
	int n=5,i,j,k;
	for(i=1;i<=n;i++)
	{
		for(j=1;j<=n;j++)
		printf(" ");
	for(k=5;k>=i;k--)
	    printf("*");
	    printf("\n");
	}
	return 0;
}
