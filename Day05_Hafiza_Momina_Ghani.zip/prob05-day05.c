#include<stdio.h>
int main()
{
    int i, j, k, range;
    char ch;
    printf("Enter range: ");
    scanf("%d", &range);
    
    for (i = 1; i <= range; i++) 
	{
        ch = 'A';
        for (j = 1; j <= range - i; j++) 
            printf(" ");
        for (k = 1; k <= i * 2 - 1; k++) 
		{
            if (k <= i) 
                printf("%c", ch++);
            else 
                printf("%c", ch--);
        }
        printf("\n");
    }
    return 0;
}
