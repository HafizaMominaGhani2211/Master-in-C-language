#include<stdio.h>

float calculateArea(float radius)
 {
    return 3.14 * radius * radius;
 }

int main() 
{
    float radius, area;
    printf("Enter radius: ");
    scanf("%f", &radius);
    area = calculateArea(radius);
    printf("Area of circle: %.1f\n", area);
    return 0;
}
