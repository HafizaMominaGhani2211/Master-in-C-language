#include<stdio.h>

int factor(int num);

int main()
{
	int num;
	printf("Number:");
	scanf("%d",&num);
	factor(num);
	return 0;
}
    int factor(int num)
   {
   	int i;
   	printf("Factors of %d :", num);
   	    for(i=1;i<=num;++i){
   	    	if(num%i==0)
   	    	   printf("%d\t", i);
		   }
		   
   }
