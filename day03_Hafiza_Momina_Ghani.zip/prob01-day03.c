#include<stdio.h>
int main()
{
   int num1, num2, num3;
   printf("Enter three numbers:");
   scanf("%d %d %d",&num1, &num2, &num3);
   if(num1==num2==num3)
   printf("All numbers are same");
   else if(num1>num2&&num1>num3)
   printf("Greatest Number: %d",num1);
   else if(num1<num2&&num1<num3)
   printf("Smallest Numbers: %d",num1);
   else if(num2>num1&&num2>num3)
   printf("Greatest Number: %d",num2);
   else if(num2<num1&&num2<num3)
   printf("Smallest Numbers: %d",num2);
   else if(num3>num2&&num3>num1)
   printf("Greatest Number: %d",num3);
   else if(num3<num2&&num3<num1)
   printf("Smallest Numbers: %d",num3);
   return 0;
}
