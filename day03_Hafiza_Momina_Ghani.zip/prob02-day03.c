#include<stdio.h>
int main()
{
	int ang1, ang2, ang3, sum;
	printf("Enter three angles of a triangle:");
	scanf("%d %d %d",&ang1, &ang2, &ang3);
	sum=ang1+ang2+ang3;
	if(sum==180)
	printf("Yes, such triangle is possible.");
	else
	printf("Sorry, such triangle can't exist.");
	return 0;
}
