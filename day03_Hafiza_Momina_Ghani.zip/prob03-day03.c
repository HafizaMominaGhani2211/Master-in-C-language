#include <stdio.h>
#include <stdlib.h>
#include <time.h>
int main()
 {
    int num1, num2, sum;
    srand(time(NULL));
    num1 = rand() % 90 + 10;
    num2 = rand() % num1;
    sum = num1 + num2;
    printf("Two random numbers: %d %d\n", num1, num2);
    if (sum % 2 == 0) 
        printf("Their sum is even.\n");
    else 
        printf("Their sum is odd.\n");

return 0;
}

