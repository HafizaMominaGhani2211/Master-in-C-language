#include <stdio.h>
int main() {
    char consumer_type;
    int units_consumed;
    float electricity_cost, gst, total_bill;
    printf("Select the Consumer type:\n");
    printf("C for commercial\n");
    printf("H for home\n");
    printf("Enter consumer type: ");
    scanf(" %c", &consumer_type);
    printf("Enter number of units consumed: ");
    scanf("%d", &units_consumed);
    if (consumer_type == 'H' || consumer_type == 'h') {
        if (units_consumed <= 100) {
            electricity_cost = units_consumed * 15;} 
	 else if (units_consumed <= 200) {
            electricity_cost = 100 * 15 + (units_consumed - 100) * 20;
        } else {
            electricity_cost = 100 * 15 + 100 * 20 + (units_consumed - 200) * 25;
        }
    } else if (consumer_type == 'C' || consumer_type == 'c') {
        if (units_consumed <= 100) {
            electricity_cost = units_consumed * 22;
        } else {
            electricity_cost = 100 * 22 + (units_consumed - 100) * 30;
        }
    } else {
        printf("Invalid consumer type\n");
        return 1;
    }
    gst = 0.1 * electricity_cost; 
    total_bill = electricity_cost + 700 + gst;
    printf("\nElectricity Cost: %.2f rupees\n", electricity_cost);
    printf("GST: %.2f rupees\n", gst);
    printf("Net Electricity Bill: %.0f rupees\n", total_bill);

    return 0;
}
