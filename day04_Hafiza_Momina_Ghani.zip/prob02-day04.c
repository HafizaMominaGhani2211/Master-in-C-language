#include<stdio.h>
int main()
{
	int num, f, i;
	printf("Number:");
	scanf("%d",&num);
	f=1;
	for(i=1;i<=num;i++)
	f=f*i;
	printf("Factorial: %d",f);
	return 0;
}
