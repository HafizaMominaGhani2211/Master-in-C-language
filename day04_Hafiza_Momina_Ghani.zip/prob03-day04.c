#include<stdio.h>
int main()
{
	int num1, num2;
	printf("Enter number1:");
	scanf("%d",&num1);
	printf("Enter number2:");
	scanf("%d",&num2);
	num1 = num1 ^ num2;
	num2 = num1 ^ num2;
	num1 = num1 ^ num2;
	printf("Number1: %d",num1);
	printf("\nNumber2: %d",num2);
	return 0;
}
