#include<stdio.h>
#include<stdlib.h>
#include<time.h>
int main()
{
	int num, guess, tries;
	tries=0;
	srand(time(0));
	num=rand() % 11 + 10;
	do{
		printf("Guess the number(10-20):");
		scanf("%d",&guess);
		tries++;
		if(guess<num)
		printf("Too low! Try again.\n");
		else if(guess>num)
		printf("Too high! try again.\n");
		else
		printf("Bravo! you guessed the number in %d tries.\n",tries);
	}
	while(guess!=num);
	return 0;
}
